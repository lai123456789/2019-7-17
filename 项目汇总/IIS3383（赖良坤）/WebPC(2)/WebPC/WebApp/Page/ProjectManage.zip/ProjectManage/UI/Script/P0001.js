﻿var 全局搜索 = '';
var 全局页码 = 1;
$(function () {
    var pj = getQueryString("pj");
    if (pj != null && pj != '') {
        var search = pj;
        全局搜索 = search;
        全局页码 = 1;
        GetUserList("IIS", "BusinessManage/AssemblyManage.aspx?action=getassemblyorderinfo", {
            "page": 1,
            "search": search
        });
    }


})



/*开启表格【全屏放大】模态窗口*/
$(document).on('click', '#datalist .fullscreen', function () {
    document.getElementById("datalist").webkitRequestFullscreen();
});

/*
导出Excel
*/
$(document).on('click', '#datalist .download', function () {
    var title = $(this).parents('.panel-heading').find('.panel-title').text();
    $('#dlink').attr('data-name', title + '.xls');
    ExportExcel('form_table');
});



$(document).on('click', '#query_title > .query_content .query_btn', function () {
    var search = $('#search_content').val();
    全局搜索 = search;
    全局页码 = 1;
    GetUserList("IIS", "BusinessManage/AssemblyManage.aspx?action=getassemblyorderinfo", {
        "page": 1,
        "search": search
    });
});


$(document).on('click', '#adduserinfo', function () {
    $("#modalDialog").draggable();//为模态对话框添加拖拽
    $("#AddUserModal").css("overflow", "hidden");//禁止模态对话框的半透明背景滚动
    $('#AddUserModal').modal('show');
});


//回车键 enter
$(document).on("keydown", document, function (e) {
    var ev = document.all ? window.event : e;
    if (ev.keyCode == 13) {
        if ($('#search_content').is(':focus')) {
            var search = $('#search_content').val();
            全局搜索 = search;
            全局页码 = 1;
            GetUserList("IIS", "BusinessManage/AssemblyManage.aspx?action=getassemblyorderinfo", {
                "search": search,
                "page": 1
            });
        }
    }
})


$(document).on('click', '#add_sex > .label.label-default', function () {
    $(this).addClass('contor').siblings().removeClass('contor');
});


$(document).on('click', '#add_sure', function () {
    var pj = $('#add_pj').val();
    var name = $('#add_name').val();
    name = name.replace(/&/g, "")
    var ordernum = $('#add_ordernum').val();
    var 工序列表 = new Array();
    var obj = $('#flowinfo tr');
    if (pj == null || pj == '') {
        alert('PJ号不能为空');
        return;
    }
    if (ordernum == null || ordernum == '') {
        alert('订单数量不能为空');
        return;
    }

    if (obj == null || obj.length == 0) {
        alert('未填写工序内容');
        return;
    }
    else
    {
        for (var i = 0; i < obj.length; i++)
        {
            var 工序号 = $(obj[i]).find('td select').val();
            var 优先级 = $(obj[i]).find('td input').val();
            var data = { "flowcode": 工序号, "priority": 优先级 };
            工序列表.push(data);
        }
    }

    AddAssemblyOrderInfo("IIS3676", "BusinessManage/AssemblyManage.aspx?action=addassemblyorderinfo", {
        "pj": pj,
        "name": name,
        "flowlist": 工序列表,
        "number": ordernum,
        "usercode": ""
    });
});


$(document).on('click', '#form_tb .printqr', function () {
    var pj = $(this).attr('data-pj');
    if (confirm("确定打印PJ号：" + pj + '的二维码吗？')) {
        PrintAssemblyQrcodeList('IIS', 'ProjectManage.aspx?action=printassemblyqrcodelist', {
            "pj": pj,
            "usercode": ""
        });
    }
});

$(document).on('click', '#form_tb .del', function () {
    var pj = $(this).attr('data-pj');
    if (confirm("确定删除PJ号：" + pj + '的所有记录吗？')) {
        DelAssemblyorderinfo('IIS', 'BusinessManage/AssemblyManage.aspx?action=delassemblyorderinfo', {
            "pj": pj,
            "usercode": ""
        });
    }
});

$(document).on('click', '#flowinfo a.del', function () {
    $(this).parents('tr').remove();
});


$(document).on('click', '#addnewflow', function () {
    var content = '';
    content += '<tr>';
    content += '    <td>';
    content += '        <select>';
    content += '            <option value="F001">组装</option>';
    content += '            <option value="F002">接线</option>';
    content += '            <option value="F003">绒布</option>';
    content += '            <option value="F004">调试</option>';
    content += '            <option value="F005">QA</option>';
    content += '            <option value="F006">打包</option>';
    content += '        </select>';
    content += '    </td>';
    content += '    <td>';
    content += '        <input type="number" min="1" max="999" value="1" />';
    content += '    </td>';
    content += '    <td>';
    content += '        <a href="JavaScript:;" class="del">删除</a>';
    content += '    </td>';
    content += '</tr>';
    $('#flowinfo').append(content)
});


/************************************* Ajax *******************************************/

/*
获取用户列表
*/
function GetUserList(urltype, pageurl, data) {
    showLoading();
    $.ajax({
        cache: true,
        type: "POST",
        dataType: "json",
        url: "/Api/WebApi.aspx?action=requestdata",
        data: {
            "urltype": urltype,
            "pageurl": pageurl,
            "data": JSON.stringify(data)
        },
        async: true,
        error: function (request) {
            hideLoading();
        },
        success: function (data) {
            hideLoading();
            if (data.errcode == 0) {
                var content = '';
                $.each(data.data, function (idx, obj) {
                    content += '<tr>';
                    content += '<td>' + obj.pj + '</td>';
                    content += '<td>' + obj.项目名称 + '</td>';
                    content += '<td>' + obj.订单数 + '</td>';
                    content += '<td>';
                    content += '<div style="float: left;margin-right: 3px;">';
                    content += '<div class="progress_white" title="' + obj.未组装明细.replace(/,/g, "") + '">' + obj.未开始数量 + '</div>';
                    content += '<div class="progress_red" title="' + obj.异常明细.replace(/,/g, "") + '">' + obj.异常数量 + '</div>';
                    content += '</div>';
                    content += '<div style="float: left;">';
                    content += '<div class="progress_yellow" title="' + obj.进行中明细.replace(/,/g, "") + '">' + obj.进行中数量 + '</div>';
                    content += '<div class="progress_green"  title="' + obj.完成明细.replace(/,/g, "") + '">' + obj.完成数量 + '</div>';
                    content += '</div>';
                    content += '</td>';
                    content += '<td>' + obj.下单人 + '</td>';
                    content += '<td>' + obj.下单时间 + '</td>';
                    content += '    <td>';
                    content += '        <a href="JavaScript:;" class="printqr" data-pj="' + obj.pj + '">打印</a>';
                    content += '        <a href="/Page/ProjectManage/P0002.html?pj=' + obj.pj + '">详情</a>';
                    if ($('#userinfo').attr('data-usercode') == "mt00000001" || $('#userinfo').attr('data-usercode') == 'mt00000489') {
                        content += '         <a class="del" data-pj="' + obj.pj + '">删除</a>'
                    }
                    content += '    </td>';
                    content += '</tr>';

                });
                $('#form_tb').empty();
                $('#form_tb').append(content);

            }
            else {
                alert(data.errmsg)
            }
        }
    });
}


/*
添加装配信息
*/
function AddAssemblyOrderInfo(urltype, pageurl, data) {
    showLoading();
    $.ajax({
        cache: true,
        type: "POST",
        dataType: "json",
        url: "/Api/WebApi.aspx?action=requestdata",
        data: {
            "urltype": urltype,
            "pageurl": pageurl,
            "data": JSON.stringify(data)
        },
        async: true,
        error: function (request) {
            hideLoading();
        },
        success: function (data) {
            hideLoading();
            if (data.errcode == 0) {
                alert('添加成功');
                $('#AddUserModal').modal('hide');
                GetUserList("IIS", "BusinessManage/AssemblyManage.aspx?action=getassemblyorderinfo", {
                    "search": 全局搜索,
                    "page": 全局页码
                });
            }
            else {
                alert(data.errmsg)
            }
        }
    });
}



/*
获取部门列表
*/
function GetDepartmentList(urltype, pageurl, data) {
    showLoading();
    $.ajax({
        cache: true,
        type: "POST",
        dataType: "json",
        url: "/Api/WebApi.aspx?action=requestdata",
        data: {
            "urltype": urltype,
            "pageurl": pageurl,
            "data": JSON.stringify(data)
        },
        async: true,
        error: function (request) {
            hideLoading();
        },
        success: function (data) {
            hideLoading();
            if (data.errcode == 0) {
                var option = '';
                $.each(data.data, function (idx, obj) {
                    option += '<option value="' + obj.departmentcode + '">' + obj.departmentname + ' （' + obj.departmentcode + '）' + '</option>';
                });
                $('#add_department').empty();
                $('#add_department').append(option);
            }
            else {
                alert(data.errmsg)
            }
        }
    });
}


/*
打印二维码
*/
function PrintAssemblyQrcodeList(urltype, pageurl, data) {
    showLoading();
    $.ajax({
        cache: true,
        type: "POST",
        dataType: "json",
        url: "/Api/WebApi.aspx?action=requestdata",
        data: {
            "urltype": urltype,
            "pageurl": pageurl,
            "data": JSON.stringify(data)
        },
        async: true,
        error: function (request) {
            hideLoading();
        },
        success: function (data) {
            hideLoading();
            if (data.errcode == 0) {
                alert('提交打印指令发送成功');
            }
            else {
                alert(data.errmsg)
            }
        }
    });
}


/*
删除订单
*/
function DelAssemblyorderinfo(urltype, pageurl, data) {
    showLoading();
    $.ajax({
        cache: true,
        type: "POST",
        dataType: "json",
        url: "/Api/WebApi.aspx?action=requestdata",
        data: {
            "urltype": urltype,
            "pageurl": pageurl,
            "data": JSON.stringify(data)
        },
        async: true,
        error: function (request) {
            hideLoading();
        },
        success: function (data) {
            hideLoading();
            if (data.errcode == 0) {
                alert('删除成功');
                GetUserList("IIS", "BusinessManage/AssemblyManage.aspx?action=getassemblyorderinfo", {
                    "search": 全局搜索,
                    "page": 全局页码
                });
            }
            else {
                alert(data.errmsg)
            }
        }
    });
}

/************************************* Ajax End *******************************************/