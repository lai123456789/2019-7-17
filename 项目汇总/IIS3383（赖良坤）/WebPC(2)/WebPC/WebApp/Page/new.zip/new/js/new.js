﻿$(document).on('click', '.add', function () {
    var content = '';
    content += '<tr>';
    content += '    <th><input type="text" value="" /></th>';
    content += '    <th><input type="text" value="" /></th>';
    content += '    <th><input type="text" value="" /></th>';
    content += '    <th><input type="text" value="" /></th>';
    content += '    <th><input type="text" value="" /></th>';
    content += '    <th><input type="text" value="" /></th>';
    content += '</tr>';
    //$("#form_tb").empty();
    $("#form_tb").append(content);
});
$(document).on('click', '.add1', function () {
    var content = '';
    content += '<tr>';
    content += '    <th><input type="text" value="" /></th>';
    content += '    <th><input type="text" value="" /></th>';
    content += '    <th><input type="text" value="" /></th>';
    content += '    <th><input type="text" value="" /></th>';
    content += '    <th><input type="text" value="" /></th>';
    content += '    <th><input type="text" value="" /></th>';
    content += '</tr>';
    //$("#form_tb").empty();
    $("#form_tb1").append(content);
})
$(document).on('click', '#form_th > tr > th', function () {
    $(this).toggleClass('contor');
    //ip = $(this).attr('data-val');  //ip表示获取每一个的表头不同th的值
    ////paixu = '';
    //if ($(this).hasClass('contor')) {
    //    paixu = 'desc';
    //}
    //else {
    //    paixu = 'asc';
    //}
    //GetAllPublishedGoodsInfo(1);
});
$(document).on('click', '#form_th1 > tr > th', function () {
    $(this).toggleClass('contor');
    
});