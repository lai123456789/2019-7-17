﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;

namespace Entity
{
    public class ExcelTable
    {
        public int errcode { get; set; }
        public string errmsg { get; set; }
        public object data { get; set; }
    }
}
