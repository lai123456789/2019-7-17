﻿function OnIntFunc() {
    
}
document.write('<link rel="shortcut icon" href="/UI/Image/logo.ico" type="image/x-icon" />');
document.write('<link href="/UI/Style/Loading.css" rel="stylesheet" />');
document.write('<link href="/assets/css/bootstrap.min.css" rel="stylesheet" />');
document.write('<link href="/assets/css/jquery.mmenu.css" rel="stylesheet" />');
document.write('<link href="/assets/css/font-awesome.min.css" rel="stylesheet" />');
document.write('<link href="/assets/css/climacons-font.css" rel="stylesheet" />');
document.write('<link href="/assets/plugins/xcharts/css/xcharts.min.css" rel="stylesheet" />');
document.write('<link href="/assets/plugins/fullcalendar/css/fullcalendar.css" rel="stylesheet" />');
document.write('<link href="/assets/plugins/morris/css/morris.css" rel="stylesheet" />');
document.write('<link href="/assets/plugins/jquery-ui/css/jquery-ui-1.10.4.min.css" rel="stylesheet" />');
document.write('<link href="/assets/plugins/jvectormap/css/jquery-jvectormap-1.2.2.css" rel="stylesheet" />');
document.write('<link href="/assets/css/style.min.css" rel="stylesheet" />');
document.write('<link href="/assets/css/add-ons.min.css?20190313" rel="stylesheet" />');
document.write('<link href="/UI/Style/iconfont.css" rel="stylesheet" />');
document.write('<link href="/UI/Style/Basic.css?20190313" rel="stylesheet" />');
document.write('<link href="/UI/Style/jquery.resizableColumns.css" rel="stylesheet" />');
document.write('<link href="/UI/Style/style.css" rel="stylesheet" />');
document.write('<scr' + 'ipt type="text/javascript" src="/UI/Scripts/Loading.js"></sc' + 'ript>');

document.write('<scr' + 'ipt type="text/javascript" src="/assets/js/jquery-migrate-1.2.1.min.js"></sc' + 'ript>');
document.write('<scr' + 'ipt type="text/javascript" src="/assets/js/bootstrap.min.js"></sc' + 'ript>');
document.write('<scr' + 'ipt type="text/javascript" src="/assets/plugins/jquery-ui/js/jquery-ui-1.10.4.min.js"></sc' + 'ript>');
document.write('<scr' + 'ipt type="text/javascript" src="/assets/plugins/touchpunch/jquery.ui.touch-punch.min.js"></sc' + 'ript>');
document.write('<scr' + 'ipt type="text/javascript" src="/assets/plugins/moment/moment.min.js"></sc' + 'ript>');
document.write('<scr' + 'ipt type="text/javascript" src="/assets/plugins/fullcalendar/js/fullcalendar.min.js"></sc' + 'ript>');
document.write('<scr' + 'ipt type="text/javascript" src="/assets/plugins/flot/jquery.flot.min.js"></sc' + 'ript>');
document.write('<scr' + 'ipt type="text/javascript" src="/assets/plugins/flot/jquery.flot.pie.min.js"></sc' + 'ript>');
document.write('<scr' + 'ipt type="text/javascript" src="/assets/plugins/flot/jquery.flot.stack.min.js"></sc' + 'ript>');
document.write('<scr' + 'ipt type="text/javascript" src="/assets/plugins/flot/jquery.flot.resize.min.js"></sc' + 'ript>');
document.write('<scr' + 'ipt type="text/javascript" src="/assets/plugins/flot/jquery.flot.time.min.js"></sc' + 'ript>');
document.write('<scr' + 'ipt type="text/javascript" src="/assets/plugins/flot/jquery.flot.spline.min.js"></sc' + 'ript>');
document.write('<scr' + 'ipt type="text/javascript" src="/assets/plugins/xcharts/js/xcharts.min.js"></sc' + 'ript>');
document.write('<scr' + 'ipt type="text/javascript" src="/assets/plugins/autosize/jquery.autosize.min.js"></sc' + 'ript>');
document.write('<scr' + 'ipt type="text/javascript" src="/assets/plugins/placeholder/jquery.placeholder.min.js"></sc' + 'ript>');
document.write('<scr' + 'ipt type="text/javascript" src="/assets/plugins/datatables/js/jquery.dataTables.min.js"></sc' + 'ript>');
document.write('<scr' + 'ipt type="text/javascript" src="/assets/plugins/datatables/js/dataTables.bootstrap.min.js"></sc' + 'ript>');
document.write('<scr' + 'ipt type="text/javascript" src="/assets/plugins/jvectormap/js/jquery-jvectormap-1.2.2.min.js"></sc' + 'ript>');
document.write('<scr' + 'ipt type="text/javascript" src="/assets/plugins/jvectormap/js/jquery-jvectormap-world-mill-en.js"></sc' + 'ript>');
document.write('<scr' + 'ipt type="text/javascript" src="/assets/plugins/jvectormap/js/gdp-data.js"></sc' + 'ript>');
document.write('<scr' + 'ipt type="text/javascript" src="/assets/plugins/gauge/gauge.min.js"></sc' + 'ript>');
document.write('<scr' + 'ipt type="text/javascript" src="/assets/js/SmoothScroll.js"></sc' + 'ript>');
document.write('<scr' + 'ipt type="text/javascript" src="/assets/js/jquery.mmenu.min.js"></sc' + 'ript>');
document.write('<scr' + 'ipt type="text/javascript" src="/assets/js/core.min.js"></sc' + 'ript>');
document.write('<scr' + 'ipt type="text/javascript" src="/assets/plugins/d3/d3.min.js"></sc' + 'ript>');
document.write('<scr' + 'ipt type="text/javascript" src="/UI/Scripts/ExcelManage.js"></sc' + 'ript>');
document.write('<scr' + 'ipt type="text/javascript" src="/UI/Scripts/jquery-ui.min.js"></sc' + 'ript>');
document.write('<scr' + 'ipt type="text/javascript" src="/UI/Scripts/DateFormat.js"></sc' + 'ript>');
document.write('<scr' + 'ipt type="text/javascript" src="/UI/Scripts/pagination.min.js"></sc' + 'ript>');
document.write('<scr' + 'ipt type="text/javascript" src="/UI/Scripts/store.js"></sc' + 'ript>');
document.write('<scr' + 'ipt type="text/javascript" src="/UI/Scripts/jquery.ResizableColumns.js"></sc' + 'ript>');
$(function () {
    
    var before_html = '';
    before_html += '<div class="navbar" role="navigation">';
    before_html += '    <div class="container-fluid">';
    before_html += '        <ul class="nav navbar-nav navbar-actions navbar-left">';
    before_html += '            <li class="visible-md visible-lg"><a id="main-menu-toggle"><i class="fa fa-th-large"></i></a></li>';
    before_html += '            <li class="visible-xs visible-sm"><a id="sidebar-menu"><i class="fa fa-navicon"></i></a></li>';
    before_html += '        </ul>';
    before_html += '        <div class="copyrights">Collect from</div>';
    before_html += '        <ul class="nav navbar-nav navbar-right">';
    before_html += '            <li class="dropdown visible-md visible-lg" id="myaccepttaskmsg">';
    //before_html += '                <a href="JavaScript:;" class="dropdown-toggle" data-toggle="dropdown"><i class="fa fa-flag"></i><span class="badge">2</span></a>';
    //before_html += '                <ul class="dropdown-menu">';
    //before_html += '                    <li class="avatar">';
    //before_html += '                        <a href="JavaScript:;">';
    //before_html += '                            <img class="avatar" src="/UI/Image/head.jpg">';
    //before_html += '                            <div>新消息</div>';
    //before_html += '                            <small>1分钟前</small>';
    //before_html += '                            <span class="label label-info">NEW</span>';
    //before_html += '                        </a>';
    //before_html += '                    </li>';
    //before_html += '                    <li class="dropdown-menu-footer text-center">';
    //before_html += '                        <a href="JavaScript:;">查看所有信息</a>';
    //before_html += '                    </li>';
    //before_html += '                </ul>';
    before_html += '            </li>';
    before_html += '            <li class="dropdown visible-md visible-lg" id="mytaskmsg">';
    //before_html += '                <a href="JavaScript:;" class="dropdown-toggle" data-toggle="dropdown"><i class="fa fa-flag"></i><span class="badge">2</span></a>';
    //before_html += '                <ul class="dropdown-menu">';
    //before_html += '                    <li class="avatar">';
    //before_html += '                        <a href="JavaScript:;">';
    //before_html += '                            <img class="avatar" src="/UI/Image/head.jpg">';
    //before_html += '                            <div>新消息</div>';
    //before_html += '                            <small>1分钟前</small>';
    //before_html += '                            <span class="label label-info">NEW</span>';
    //before_html += '                        </a>';
    //before_html += '                    </li>';
    //before_html += '                    <li class="dropdown-menu-footer text-center">';
    //before_html += '                        <a href="JavaScript:;">查看所有信息</a>';
    //before_html += '                    </li>';
    //before_html += '                </ul>';
    before_html += '            </li>';
    before_html += '            <li class="dropdown visible-md visible-lg" id="tasknotifymsg">';
    //before_html += '                <a href="JavaScript:;" class="dropdown-toggle" data-toggle="dropdown"><i class="fa fa-envelope-o"></i><span class="badge">2</span></a>';
    //before_html += '                <ul class="dropdown-menu">';
    //before_html += '                    <li class="avatar">';
    //before_html += '                        <a href="JavaScript:;">';
    //before_html += '                            <img class="avatar" src="/UI/Image/head.jpg">';
    //before_html += '                            <div>新消息</div>';
    //before_html += '                            <small>1分钟前</small>';
    //before_html += '                            <span class="label label-info">NEW</span>';
    //before_html += '                        </a>';
    //before_html += '                    </li>';
    //before_html += '                    <li class="dropdown-menu-footer text-center">';
    //before_html += '                        <a href="JavaScript:;">查看所有信息</a>';
    //before_html += '                    </li>';
    //before_html += '                </ul>';
    before_html += '            </li>';
    before_html += '            <li class="dropdown visible-md visible-lg noshow" id="notifymsg">';
    //before_html += '                <a href="JavaScript:;" class="dropdown-toggle" data-toggle="dropdown"><i class="fa fa-bell-o"></i><span class="badge">2</span></a>';
    //before_html += '                <ul class="dropdown-menu">';
    //before_html += '                    <li class="clearfix">';
    //before_html += '                        <i class="fa fa-comment"></i>';
    //before_html += '                        <a href="JavaScript:;" class="notification-user"> 张三 </a>';
    //before_html += '                        <span class="notification-action">有新回复</span>';
    //before_html += '                        <a href="JavaScript:;" class="notification-link">查看</a>';
    //before_html += '                    </li>';
    //before_html += '                </ul>';
    before_html += '            </li>';
    before_html += '            <li class="dropdown visible-md visible-lg">';
    before_html += '                <a href="JavaScript:;" class="dropdown-toggle" data-toggle="dropdown" id="userinfo"><img class="user-avatar" src="/UI/Image/head.jpg" alt="user-mail"></a>';
    before_html += '                <ul class="dropdown-menu">';
    before_html += '                    <li class="dropdown-menu-header">';
    before_html += '                        <strong>账号信息</strong>';
    before_html += '                    </li>';
    before_html += '                    <li><a href="/Page/BasicData/PersonalInfo.html"><i class="fa fa-user"></i>个人资料</a></li>';
    before_html += '                    <li class="divider"></li>';
    before_html += '                    <li><a href="JavaScript:;" id="logout"><i class="fa fa-sign-out"></i>注销</a></li>';
    before_html += '                </ul>';
    before_html += '            </li>';
    before_html += '        </ul>';
    before_html += '    </div>';
    before_html += '</div>';
    before_html += '<div class="container-fluid content">';
    before_html += '    <div class="row">';
    before_html += '        <div class="sidebar ">';
    before_html += '            <div class="sidebar-collapse">';
    before_html += '                <div class="sidebar-header t-center">';
    before_html += '                    <span><img class="text-logo" src="/UI/Image/logo_head.png"></span>';
    before_html += '                </div>';
    before_html += '                <div class="sidebar-menu">';
    before_html += '                    <ul class="nav nav-sidebar" id="menulist">';

    before_html += '                    </ul>';
    before_html += '                </div>';
    before_html += '            </div>';
    before_html += '            <div class="sidebar-footer">';
    before_html += '                <div class="sidebar-brand">';
    before_html += '                    Mountain';
    before_html += '                </div>';
    before_html += '            </div>';
    before_html += '        </div>';
    $('#main').before(before_html);
    var after_html = '';
    after_html += '    </div>';
    after_html += '</div>';
    after_html += '<form id="export_excel" action="/Api/WebApi.aspx?action=tableexport" target="_blank" method="post">';
    after_html += '    <input id="urltype" name="urltype" type="hidden" value="" />';
    after_html += '    <input id="pageurl" name="pageurl" type="hidden" value="" />';
    after_html += '    <input id="data" name="data" type="hidden" value="" />';
    after_html += '    <input id="filename" name="filename" type="hidden" value="" />';
    after_html += '</form>';
    after_html += '<input type="file" value="" id="fileval" name="files" style="display:none;" />';
    $('#main').after(after_html);

});

/*
获取URL参数
*/
function getQueryString(name) {
    var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)", "i");
    var r = window.location.search.substr(1).match(reg);
    if (r != null) return unescape(r[2]);
    return null;
}



$(document).on('click', '#logout', function () {
    UserLogout();
});

$(document).on('click', '.btn_notifymsg', function () {
    var notifycode = $(this).attr('data-notifycode');
    var url = $(this).attr('data-url');
    SetUserReadNotify(notifycode, function () {
        location.href = url;
    });
});



var timer1;
$(function () {
    GetUserPageList();
    TimerCheck();
    Global_GetUserInfo();
});


/*
定时检查
*/
function TimerCheck() {
    CheckUser();
    timer1 = setTimeout(function () {
        TimerCheck();
    }, 15000);
}

/*
检查用户登录状态
*/
function CheckUser() {
    $.ajax({
        cache: true,
        type: "POST",
        dataType: "json",
        url: "/Api/WebApi.aspx?action=checkuser",
        async: true,
        error: function (request) {
        },
        success: function (data) {
            if (data.errcode == 0) {
                //后面弹窗提示之类的信息在这里体现
                var sum = 0;
                if (data.notify != null && data.notify != '' && data.notify != '[]')
                {
                    var content_1 = '';
                    var content_2 = '';
                    $('#notifymsg').empty();
                    content_2 += '<ul class="dropdown-menu">';
                    $.each(eval('(' + data.notify + ')'), function (idx, obj) {
                        var 标题 = obj.标题;
                        var 内容 = obj.内容;
                        var 跳转页面 = obj.跳转页面;
                        var 通知代码 = obj.通知代码;
                        
                        sum += 1;
                        if (idx < 3) {
                            setTimeout(function () {
                                NotifyShow(标题, 内容, 跳转页面, 通知代码);
                            }, (1000 * idx) + 1000);
                            content_2 += '    <li class="clearfix">';
                            content_2 += '        <i class="fa fa-comment"></i>';
                            content_2 += '        <a href="JavaScript:;" data-notifycode="' + 通知代码 + '" data-url="' + 跳转页面 + '" class="btn_notifymsg notification-user">' + 标题 + '</a>';
                            content_2 += '        <a href="JavaScript:;" data-notifycode="' + 通知代码 + '" data-url="' + 跳转页面 + '" class="btn_notifymsg notification-link">查看</a>';
                            content_2 += '    </li>';
                        }
                    });
                    content_2 += '</ul>';
                    content_1 += '<a href="JavaScript:;" class="dropdown-toggle" data-toggle="dropdown">';
                    content_1 += '<i class="fa fa-bell-o"></i>';
                    content_1 += '<span class="badge">' + sum + '</span>';
                    content_1 += '</a>';
                    var content = content_1 + content_2;
                    $('#notifymsg').append(content);
                };
                if (sum == 0) {
                    $('#notifymsg').addClass('noshow');
                } else {
                    $('#notifymsg').removeClass('noshow');
                }




                var content2_1 = '';
                var content2_2 = '';
                sum = 0;
                if (data.tasknotify != null && data.tasknotify != '' && data.tasknotify != '[]') {
                    $('#tasknotifymsg').empty();
                    content2_2 += '<ul class="dropdown-menu">';
                    $.each(eval('(' + data.tasknotify + ')'), function (idx, obj) {
                        var 任务类型 = obj.任务类型;
                        var 任务标题 = obj.任务标题;
                        var 跳转页面 = obj.PC跳转页面;
                        var 任务创建时间 = obj.任务创建时间;
                        
                        sum += 1;
                        if (idx < 3) {
                            setTimeout(function () {
                                NotifyShow(任务类型, 任务标题, 跳转页面, '');
                            }, (1000 * idx) + 1000);
                            content2_2 += '    <li class="avatar">';
                            content2_2 += '        <a href="' + 跳转页面 + '">';
                            switch (任务类型) {
                                case "装配异常":
                                    content2_2 += '        <img class="avatar" src="/UI/Image/异常.png">';
                                    break;
                                default:
                                    content2_2 += '        <img class="avatar" src="/UI/Image/head.jpg">';
                                    break;
                            }
                            content2_2 += '        <div>' + 任务标题 + '</div>';
                            content2_2 += '        <small>' + 任务创建时间 + '</small>';
                            content2_2 += '        <span class="label label-info">NEW</span></a>';
                            content2_2 += '    </li>';
                        }
                    });
                    content2_2 += '</ul>';
                    content2_1 += '<a href="JavaScript:;" class="dropdown-toggle" data-toggle="dropdown">';
                    content2_1 += '<i class="fa fa-envelope-o"></i>';
                    content2_1 += '<span class="badge">' + sum + '</span>';
                    content2_1 += '</a>';

                    var content = content2_1 + content2_2;
                    $('#tasknotifymsg').append(content);
                };
                if (sum == 0) {
                    $('#tasknotifymsg').addClass('noshow');
                } else {
                    $('#tasknotifymsg').removeClass('noshow');
                }






                var content3_1 = '';
                var content3_2 = '';
                sum = 0;
                content3_2 += '<ul class="dropdown-menu">';
                $('#mytaskmsg').empty();
                if (data.mytaskunfinished != null && data.mytaskunfinished != '' && data.mytaskunfinished != '[]') {
                    $.each(eval('(' + data.mytaskunfinished + ')'), function (idx, obj) {
                        var 任务类型 = obj.任务类型;
                        var 任务标题 = obj.任务类型;
                        var 跳转页面 = '/Page/Task/MyTastList.html?status=2&&taskcode=' + obj.任务代码;
                        var 创建时间 = obj.创建时间;
                        
                        sum += 1;
                        if (idx < 3) {
                            content3_2 += '    <li class="avatar">';
                            content3_2 += '        <a href="' + 跳转页面 + '">';
                            switch (任务类型) {
                                case "装配异常":
                                    content3_2 += '        <img class="avatar" src="/UI/Image/异常.png">';
                                    break;
                                default:
                                    content3_2 += '        <img class="avatar" src="/UI/Image/head.jpg">';
                                    break;
                            }
                            content3_2 += '        <div>' + 任务标题 + '</div>';
                            content3_2 += '        <small>' + 创建时间 + '</small>';
                            content3_2 += '        <span class="label label-info" style="background-color: #fabb3d !important;">进行中</span></a>';
                            content3_2 += '    </li>';
                        }
                    });
                };
                content3_1 += '<a href="JavaScript:;" class="dropdown-toggle" data-toggle="dropdown">';
                content3_1 += '<i class="fa fa-flag"></i>';
                if (parseFloat(sum) > 0) {
                    content3_1 += '<span class="badge">' + sum + '</span>';
                }
                content3_1 += '</a>';

                content3_2 += '<li class="dropdown-menu-footer text-center">';
                content3_2 += '    <a href="/Page/Task/MyTastList.html?status=2">查看所有信息</a>';
                content3_2 += '</li>';
                content3_2 += '</ul>';

                var content = content3_1 + content3_2;
                $('#mytaskmsg').append(content);


                //var content4_1 = '';
                //var content4_2 = '';
                //sum = 0;
                //content4_2 += '<ul class="dropdown-menu">';
                //$('#myaccepttaskmsg').empty();
                //if (data.myaccepttask != null && data.myaccepttask != '' && data.myaccepttask != '[]') {
                //    $.each(eval('(' + data.myaccepttask + ')'), function (idx, obj) {
                //        var 任务类型 = obj.任务类型;
                //        var 任务标题 = obj.任务类型;
                //        var 跳转页面 = '/Page/Task/MyTastList.html?status=2&&taskcode=' + obj.任务代码;
                //        var 创建时间 = obj.创建时间;

                //        sum += 1;
                //        content4_2 += '    <li class="avatar">';
                //        content4_2 += '        <a href="' + 跳转页面 + '">';
                //        switch (任务类型) {
                //            case "装配异常":
                //                content4_2 += '        <img class="avatar" src="/UI/Image/异常.png">';
                //                break;
                //            default:
                //                content4_2 += '        <img class="avatar" src="/UI/Image/head.jpg">';
                //                break;
                //        }
                //        content4_2 += '        <div>' + 任务标题 + '</div>';
                //        content4_2 += '        <small>' + 创建时间 + '</small>';
                //        content4_2 += '        <span class="label label-info" style="background-color: #fabb3d !important;">进行中</span></a>';
                //        content4_2 += '    </li>';
                //    });
                //};
                //content4_1 += '<a href="JavaScript:;" class="dropdown-toggle" data-toggle="dropdown">';
                //content4_1 += '<i class="fa fa-flag-checkered"></i>';
                //if (parseFloat(sum) > 0) {
                //    content4_1 += '<span class="badge">' + sum + '</span>';
                //}
                //content4_1 += '</a>';

                //content4_2 += '<li class="dropdown-menu-footer text-center">';
                //content4_2 += '    <a href="/Page/Task/MyTastList.html?status=2">查看所有信息</a>';
                //content4_2 += '</li>';
                //content4_2 += '</ul>';

                //var content = content4_1 + content4_2;
                //$('#myaccepttaskmsg').append(content);
            }
            else {
                alert(data.errmsg);
                location.href = '/Page/Login.html';
            }
        }
    });
}


function NotifyShow(title, content, url, notifycode) {
    if (!window.Notification) {
        //alert("浏览器不支持通知！");
    }
    if (window.Notification.permission != 'granted') {
        Notification.requestPermission(function (status) {
            //status是授权状态，如果用户允许显示桌面通知，则status为'granted'
            //console.log('status: ' + status);
            //permission只读属性:
            //  default 用户没有接收或拒绝授权 不能显示通知
            //  granted 用户接受授权 允许显示通知
            //  denied  用户拒绝授权 不允许显示通知
            //var permission = Notification.permission;
            //console.log('permission: ' + permission);
        });
    }
    var n = new Notification(title, { "icon": "", "body": content });
    n.onshow = function () {
        //console.log("显示通知");
        setTimeout(function () { n.close() }, 10000);
    };
    n.onclick = function () {
        //alert("打开相关视图");
        if (notifycode != null && notifycode != '') {
            SetUserReadNotify(notifycode, function () {
                location.href = url;
                n.close();
            });
        } else {
            location.href = url;
            n.close();
        }
    };
    n.onclose = function () {
        //console.log("通知关闭");
    };
    n.onerror = function (err) {
        console.log(err);
    };
}


/*
用户注销
*/
function UserLogout() {
    $.ajax({
        cache: true,
        type: "POST",
        dataType: "json",
        url: "/Api/WebApi.aspx?action=logout",
        async: true,
        error: function (request) {
        },
        success: function (data) {
            if (data.errcode == 0) {
                //后面弹窗提示之类的信息在这里体现
                location.href = '/Page/Login.html';
            }
            else {
                alert(data.errmsg);
            }
        }
    });
}



/*
获取用户信息
*/
function Global_GetUserInfo() {
    showLoading();
    $.ajax({
        cache: true,
        type: "POST",
        dataType: "json",
        url: "/Api/WebApi.aspx?action=getuserinfo",
        async: true,
        error: function (request) {
            hideLoading();
        },
        success: function (data) {
            hideLoading();
            var content = '<img class="user-avatar" src="/UI/Image/head.jpg" alt="user-mail">' + data.username + '（' + data.account + '）';
            $('#userinfo').empty();
            $('#userinfo').append(content);
            $('#userinfo').attr('data-usercode', data.usercode);
            $("table").resizableColumns({
                store: store
            });
            OnIntFunc();
        }
    });
}


/*
获取用户页面列表
*/
function GetUserPageList() {
    $.ajax({
        cache: true,
        type: "POST",
        dataType: "json",
        url: "/Api/WebApi.aspx?action=getuserpagelist",
        async: true,
        error: function (request) {

        },
        success: function (data) {
            var content = '';
            var json_obj = new Array();
            $.each(data.data, function (idx, obj) {
                var 上级页面代码 = obj.上级页面代码;
                var 图标 = obj.图标;
                var 导航显示 = obj.导航显示;
                var 排序 = obj.排序;
                var 链接地址 = obj.链接地址;
                var 页面代码 = obj.页面代码;
                var 页面名称 = obj.页面名称;
                var data1 = {
                    "页面代码": 页面代码,
                    "页面名称": 页面名称,
                    "链接地址": 链接地址,
                    "排序": 排序,
                    "导航显示": 导航显示,
                    "图标": 图标,
                    "上级页面代码": 上级页面代码
                }
                json_obj.push(data1);
            });
            var recursion = getPageJsonTree(json_obj, '');
            FillPageList(recursion);
            
        }
    });
}

function FillPageList(对象数组) {
    var content = '';
    for (var i = 0; i < 对象数组.length; i++) {
        if (对象数组[i].子级列表.length == 0) {
            content += '<li>';
            content += '<a href="' + 对象数组[i].链接地址 + '"><i class="' + 对象数组[i].图标 + '"></i><span class="text">' + 对象数组[i].页面名称 + '</span></a>';
            content += '</li>';
        }
        else {
            content += '<li>';
            content += '<a href="JavaScript:;"><i class="' + 对象数组[i].图标 + '"></i><span class="text">' + 对象数组[i].页面名称 + '</span> <span class="fa fa-angle-down pull-right"></span></a>';
            content += '<ul class="nav sub">';
            for (var j = 0; j < 对象数组[i].子级列表.length; j++) {
                content += '<li><a href="' + 对象数组[i].子级列表[j].链接地址 + '"><i class="' + 对象数组[i].子级列表[j].图标 + '"></i><span class="text">' + 对象数组[i].子级列表[j].页面名称 + '</span></a></li>';
            }
            content += '</ul>';
            content += '</li>';
        }
    }
    $('#menulist').empty();
    $('#menulist').append(content); 
    MenuInit();
}


/*
递归
*/
var getPageJsonTree = function (对象数组, 上级代码) {
    var itemArr = [];
    for (var i = 0; i < 对象数组.length; i++) {
        var node = 对象数组[i];
        if (node.上级页面代码 == 上级代码) {
            var newNode = {
                "页面代码": node.页面代码,
                "页面名称": node.页面名称,
                "链接地址": node.链接地址,
                "排序": node.排序,
                "导航显示": node.导航显示,
                "图标": node.图标,
                "子级列表": getPageJsonTree(对象数组, node.页面代码)
            };
            itemArr.push(newNode);
        }
    }
    return itemArr;
}




/*
设置通知已读
*/
function SetUserReadNotify(notifycode, Func) {
    $.ajax({
        cache: true,
        type: "POST",
        dataType: "json",
        url: "/Api/WebApi.aspx?action=setuserreadnotify",
        data: {
            "notifycode": notifycode
        },
        async: true,
        error: function (request) {
        },
        success: function (data) {
            if (data.errcode == 0) {
                if (Func != null) {
                    Func();
                }
            }
            else {
                alert(data.errmsg);
            }
        }
    });
}