var data1 = [{ title: '苹果' }, { title: '香蕉' }, { title: '梨子' }, { title: '火龙果' }, { title: '芒果' }, { title: '菠萝' }];

var data2 = [{value:1,text:'苹果'},{value:2,text:'香蕉'},{value:3,text:'梨子'},{value:4,text:'火龙果'},{value:5,text:'芒果'},{value:6,text:'菠萝'}];

var data3 = [{value:1,text:'apple',form:'世纪苹果店1'},{value:2,text:'Banana',form:'进口店2'},
			{value:3,text:'appleGo',form:'苹果店3'},{value:5,text:'apple',form:'苹果店4'},
			{value:4,text:'appleGo',form:'苹果店5'},{value:6,text:'Banana',form:'进口店店6'},
			{value:8,text:'appleGo1',form:'苹果店7'},{value:7,text:'苹果',form:'苹果店8'}];