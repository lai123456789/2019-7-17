﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Entity
{
    public class Ent_JsApiTicket
    {
        public int errcode;
        public string errmsg;
        public string ticket;
        public int expires_in;
    }
}
