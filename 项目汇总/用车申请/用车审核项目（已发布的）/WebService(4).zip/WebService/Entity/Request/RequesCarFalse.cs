﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Entity.Request
{
   public  class RequesCarFalse
    {
       public string applycode { get; set; }
        public string reason { get; set; }
        public string playcode { get; set; }
        public string begin { get; set; }
         public string usercode { get; set; }
        public string endplay { get; set; }
        public string returnremark { get; set; }
        public string susercode { get; set; }
       
    }
}
