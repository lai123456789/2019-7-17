﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Entity.Request
{
  public  class RequesChoose
    {

      public 数据[] 类型 { get; set; }
}

public class 数据
{
public string pagecode { get; set; }
public string search { get; set; }
public string pagesize { get; set; }
public string page { get; set; }
public string totalnum { get; set; }
public string pagecount { get; set; }






}

//search, pagesize, page, totalnum, pagecount, 
}
