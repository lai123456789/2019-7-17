﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Entity.Request
{
    public  class RequesGetFalseB
    {
        public string nowrow { get; set; }
        public string pagecode { get; set; }
      
    }
}
