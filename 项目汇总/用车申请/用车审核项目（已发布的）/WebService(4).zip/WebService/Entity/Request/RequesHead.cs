﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Entity.Request
{
    public class RequesHead
    {
       public string pagecode { get; set; }
public string usercode { get; set; }
public string nowrow { get; set; }
public string hname { get; set; }
public string nowline { get; set; }

    }


    }


//        public 编辑表头的数据[] 编辑表头的数据 { get; set; }
//}

//       public class 编辑表头的数据
//            {
//            public string pagecode { get; set; }
//            public string nowrow { get; set; }
//            public string nowline { get; set; }
//            public string hname { get; set; }
//            public string usercode { get; set; }
//            }
 
    

