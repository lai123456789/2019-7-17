﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Entity.Request
{
   public class RequesReCar
    {
        public string applycode { get; set; }
        public string returnremark { get; set; }
        public string playcode { get; set; }
        public string endplay { get; set; }
     
    }
}
