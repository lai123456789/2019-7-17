﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Entity.Request
{
  public  class RequestGet
    {

        
      public string pagecode { get; set; }
     
      public string rolecode { get; set; }

    }
}
