﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Entity.Request
{
   public class RequestUser
    {

       public string usercode { get; set; }
       public string username { get; set; }
       public string base64 { get; set; }
       public string wordercode { get; set; }
       public string WordTypeCode { get; set; }

       public string apptittle { get; set; }
       public string content { get; set; }
       public string gdState { get; set; }
       public string CREATETIME { get; set; }
       public string imgtype { get; set; }


    }
}
