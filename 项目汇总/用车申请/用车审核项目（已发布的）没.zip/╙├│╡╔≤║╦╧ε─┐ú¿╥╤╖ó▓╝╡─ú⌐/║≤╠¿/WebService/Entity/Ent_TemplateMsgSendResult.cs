﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Entity
{
    [Serializable]
    public class Ent_TemplateMsgSendResult
    {
        public int errcode;
        public string errmsg;
        public string msgid;
    }
}