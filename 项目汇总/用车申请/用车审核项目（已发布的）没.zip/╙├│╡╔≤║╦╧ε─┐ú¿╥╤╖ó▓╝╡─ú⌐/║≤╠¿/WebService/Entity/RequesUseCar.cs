﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Entity.Request
{
 public   class RequesUseCar
    {

     public string onetype { get; set; }
     public string oneval { get; set; }
     public string twotype { get; set; }
     public string twoval { get; set; }

     public string datetype { get; set; }

     public string startdate { get; set; }

     public string enddate { get; set; }

       public string username { get; set; }

     public string applyname { get; set; }
     public string sort { get; set; }

     public string sortfield { get; set; }

       
    }
 
}
