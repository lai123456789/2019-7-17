﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Entity.Request
{
  public  class RequesCarNums
    {
        public string remark { get; set; }

        public string platenumber { get; set; }

        public string applycode { get; set; }
        public string susercode { get; set; }
    
        public string driver { get; set; }
    }
}
