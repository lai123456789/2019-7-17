﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Entity.Request
{
   public class RequesDCar
    {
       public string applycode { get; set; }
        public string delayedtime { get; set; }

        public string platenumber { get; set; }
        public string Oldplatenumber { get; set; }
        public string reremark { get; set; }
      
       
    }
}
