﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Entity.Request
{
    public class RequesDelete
    {
//        public string hcode { get; set; }

//        public string pagecode { get; set; }

//        public string usercode { get; set; }


//        public class RequesDelete
//{
public 要删除的数据[] 要删除的数据 { get; set; }
}

public class 要删除的数据
{
public string pagecode { get; set; }
public string hcode { get; set; }
public string usercode { get; set; }
}



    
}
