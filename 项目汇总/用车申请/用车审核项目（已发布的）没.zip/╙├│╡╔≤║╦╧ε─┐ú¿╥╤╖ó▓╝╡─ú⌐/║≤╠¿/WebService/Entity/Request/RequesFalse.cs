﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Entity.Request
{
   public class RequesFalse
    {

       public string nowrows { get; set; }
        public string pagecode { get; set; }

        public string usercode { get; set; }
        public string sort { get; set; }
        public string cause { get; set; }

        //nowrows, sort, cause,
    }
}
