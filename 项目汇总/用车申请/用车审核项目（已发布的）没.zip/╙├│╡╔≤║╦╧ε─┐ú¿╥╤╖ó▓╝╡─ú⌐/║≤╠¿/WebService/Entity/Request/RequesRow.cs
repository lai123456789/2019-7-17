﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Entity.Request
{
  public  class RequesRow
    {     

public 编辑的数据[] 编辑的数据 { get; set; }
}

public class 编辑的数据
{
public string pagecode { get; set; }
public string nowrow { get; set; }
public string nowline { get; set; }
public string content { get; set; }
public string usercode { get; set; }
public string hcode { get; set; }
}
 
}
