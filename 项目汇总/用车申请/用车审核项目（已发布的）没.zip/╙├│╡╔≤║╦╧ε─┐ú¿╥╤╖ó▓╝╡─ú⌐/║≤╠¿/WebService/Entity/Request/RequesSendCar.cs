﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Entity.Request
{
   public class RequesSendCar
    {
       public string applyname { get; set; }

       public string accent { get; set; }
       public string proposernomber { get; set; }
       public string endsite { get; set; }
       public string purpose { get; set; }
       public string servicetime { get; set; }
       public string usercode { get; set; }
         public string department { get; set; }
       
    }
}
