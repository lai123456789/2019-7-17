﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Entity.Request
{
  public  class RequesSendFalse
    {

        public string applycode { get; set; }

        public string reason { get; set; }
        public string usercode { get; set; }
        public string susercode { get; set; }
    }
}
