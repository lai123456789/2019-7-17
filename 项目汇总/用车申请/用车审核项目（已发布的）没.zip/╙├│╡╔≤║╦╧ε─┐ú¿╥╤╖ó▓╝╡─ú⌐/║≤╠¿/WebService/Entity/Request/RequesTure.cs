﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Entity.Request
{
   public class RequesTure
    {
       public string nowrows { get; set; }
       public string sort { get; set; }
       public string cause { get; set; }
        public string pagecode { get; set; }
        public string usercode { get; set; }
        //pagecode, nowrows, sort, cause, usercode,
    }
}
