﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Entity.Request
{
    public  class RequestGetAll
    {

        public string pagecode { get; set; }
        public string usercode { get; set; }

    }
}
