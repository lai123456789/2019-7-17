﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Entity.Request
{
    public class TestDome
    {
        public string Item { get; set; }
        public string Sprint内容 { get; set; }
        public string Activity行动 { get; set; }
        public string Progress进度 { get; set; }
        public string RES负责人 { get; set; }
        public string plantime { get; set; }
        public string planendtime { get; set; }
        public string usercode { get; set; }
    }
}
